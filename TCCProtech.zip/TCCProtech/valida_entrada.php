<?php
include 'conexao.php';
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql ="SELECT * FROM usuario where email='$email' and senha= md5('$senha') ";

$result = $mysqli->query($sql); 
$row = $result->num_rows; 

if($row == 0) {
header("Refresh: 1; entrar.php");
}
else {
header("Refresh: 1; index.php"); 
}
?>

