<?php
include 'conexao.php';
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql =" INSERT INTO usuario( nome, email, senha)VALUES( '$nome', '$email', (md5('$senha')))";

$mysqli->query($sql);

header("Refresh: 1; entrar.php");

?>
